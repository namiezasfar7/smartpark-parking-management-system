package com.smartpark.service;

import com.smartpark.model.Vehicle;
import com.smartpark.repository.VehicleRepository;

import java.util.List;
import java.util.Objects;

/**
 * Business logic for vehicle registration and lookup.
 * The repository is the only thing this class knows about persistence —
 * it never touches storage directly.
 */
public class VehicleService {

    private final VehicleRepository vehicleRepository;

    public VehicleService(VehicleRepository vehicleRepository) {
        this.vehicleRepository = Objects.requireNonNull(vehicleRepository, "Vehicle repository is required");
    }

    /** Registers a new vehicle by saving it through the repository. */
    public void registerVehicle(Vehicle vehicle) {
        Objects.requireNonNull(vehicle, "Vehicle cannot be null");
        vehicleRepository.save(vehicle);
    }

    public Vehicle findVehicle(String registrationNumber) {
        return vehicleRepository.findByRegistrationNumber(registrationNumber);
    }

    public List<Vehicle> getAllVehicles() {
        return vehicleRepository.findAll();
    }
}
