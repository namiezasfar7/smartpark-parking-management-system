package com.smartpark.service;

import com.smartpark.model.ParkingSession;
import com.smartpark.model.ParkingSessionStatus;
import com.smartpark.model.ParkingSpace;
import com.smartpark.model.ParkingSpaceStatus;
import com.smartpark.repository.ParkingSessionRepository;
import com.smartpark.repository.ParkingSpaceRepository;

import java.util.List;
import java.util.Objects;

/**
 * Business logic for opening and closing parking sessions.
 * Every method that touches a ParkingSpace goes through
 * requireExistingSpace() so the "does this space actually exist" check
 * only lives in one place.
 */
public class ParkingSessionService {

    private final ParkingSessionRepository parkingSessionRepository;
    private final ParkingSpaceRepository parkingSpaceRepository;

    public ParkingSessionService(ParkingSessionRepository parkingSessionRepository,
                                  ParkingSpaceRepository parkingSpaceRepository) {
        this.parkingSessionRepository = Objects.requireNonNull(parkingSessionRepository, "Parking session repository is required");
        this.parkingSpaceRepository = Objects.requireNonNull(parkingSpaceRepository, "Parking space repository is required");
    }

    /** Opens a session: marks its space OCCUPIED and stores the session. */
    public void startSession(ParkingSession session) {
        if (session == null) {
            throw new IllegalArgumentException("Parking session cannot be null.");
        }
        if (session.getParkingSpace() == null) {
            throw new IllegalArgumentException("Parking space cannot be null.");
        }

        ParkingSpace actualSpace = requireExistingSpace(session.getParkingSpace().getSpaceId());

        if (actualSpace.getStatus() != ParkingSpaceStatus.AVAILABLE) {
            throw new IllegalStateException("Parking space is not available.");
        }

        actualSpace.setStatus(ParkingSpaceStatus.OCCUPIED);
        parkingSessionRepository.save(session);
    }

    public ParkingSession findSession(String sessionId) {
        return parkingSessionRepository.findBySessionId(sessionId);
    }

    public List<ParkingSession> getAllSessions() {
        return parkingSessionRepository.findAll();
    }

    /** Closes a session and frees its space. Calling this twice is harmless. */
    public void completeSession(String sessionId) {
        ParkingSession session = parkingSessionRepository.findBySessionId(sessionId);
        if (session == null) {
            throw new IllegalArgumentException("Parking session not found.");
        }
        if (session.getStatus() == ParkingSessionStatus.COMPLETED) {
            return;
        }

        session.completeSession();
        freeSpaceIfPresent(session.getParkingSpace());
    }

    private ParkingSpace requireExistingSpace(String spaceId) {
        ParkingSpace space = parkingSpaceRepository.findBySpaceId(spaceId);
        if (space == null) {
            throw new IllegalArgumentException("Parking space does not exist.");
        }
        return space;
    }

    private void freeSpaceIfPresent(ParkingSpace parkingSpace) {
        if (parkingSpace == null) {
            return;
        }
        ParkingSpace actualSpace = parkingSpaceRepository.findBySpaceId(parkingSpace.getSpaceId());
        if (actualSpace != null) {
            actualSpace.setStatus(ParkingSpaceStatus.AVAILABLE);
        }
    }
}
