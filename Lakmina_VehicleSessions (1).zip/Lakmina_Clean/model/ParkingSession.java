package com.smartpark.model;

import java.util.Objects;

/**
 * One vehicle's stay in a parking space, from entry to exit.
 * Entry/exit times stay as Strings to match how the rest of the app
 * already formats and displays them — only the internals are restyled here.
 */
public class ParkingSession {

    private final String sessionId;
    private final Vehicle vehicle;
    private final ParkingSpace parkingSpace;
    private String entryTime;
    private String exitTime;
    private ParkingSessionStatus status;

    public ParkingSession(String sessionId, Vehicle vehicle, ParkingSpace parkingSpace, String entryTime) {
        this.sessionId = Objects.requireNonNull(sessionId, "Session ID is required");
        this.vehicle = Objects.requireNonNull(vehicle, "Vehicle is required");
        this.parkingSpace = Objects.requireNonNull(parkingSpace, "Parking space is required");
        this.entryTime = Objects.requireNonNull(entryTime, "Entry time is required");
        this.status = ParkingSessionStatus.ACTIVE;
    }

    public String getSessionId() {
        return sessionId;
    }

    public Vehicle getVehicle() {
        return vehicle;
    }

    public ParkingSpace getParkingSpace() {
        return parkingSpace;
    }

    public String getEntryTime() {
        return entryTime;
    }

    public String getExitTime() {
        return exitTime;
    }

    public ParkingSessionStatus getStatus() {
        return status;
    }

    public void setEntryTime(String entryTime) {
        this.entryTime = entryTime;
    }

    public void setExitTime(String exitTime) {
        this.exitTime = exitTime;
    }

    public void setStatus(ParkingSessionStatus status) {
        this.status = status;
    }

    /** Marks this session finished. Safe to call more than once — it just stays COMPLETED. */
    public void completeSession() {
        this.status = ParkingSessionStatus.COMPLETED;
    }

    @Override
    public String toString() {
        return "ParkingSession{sessionId='%s', vehicle=%s, parkingSpace=%s, entryTime=%s, exitTime=%s, status=%s}"
                .formatted(sessionId, vehicle, parkingSpace, entryTime, exitTime, status);
    }
}
