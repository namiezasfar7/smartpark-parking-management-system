package com.smartpark.model;

import java.util.Arrays;

/**
 * The category of a registered vehicle.
 * CAR / BIKE / VAN are the only values the rest of the system relies on —
 * nothing here changes that contract, this just adds a short code and a
 * lookup helper that the UI layer can use instead of calling name() directly.
 */
public enum VehicleType {

    CAR("CAR"),
    BIKE("BIKE"),
    VAN("VAN");

    private final String code;

    VehicleType(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }

    /** Looks up a VehicleType by its short code, case-insensitive. */
    public static VehicleType fromCode(String code) {
        return Arrays.stream(values())
                .filter(type -> type.code.equalsIgnoreCase(code))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Unknown vehicle type code: " + code));
    }
}
