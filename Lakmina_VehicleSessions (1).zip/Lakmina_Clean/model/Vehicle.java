package com.smartpark.model;

import java.util.Objects;

/**
 * A registered vehicle. Registration number is the natural identifier and
 * never changes after creation; owner name can be updated (e.g. if a
 * vehicle changes hands).
 */
public class Vehicle {

    private final String registrationNumber;
    private String ownerName;
    private final VehicleType vehicleType;

    public Vehicle(String registrationNumber, String ownerName, VehicleType vehicleType) {
        this.registrationNumber = requireText(registrationNumber, "Registration number");
        this.ownerName = requireText(ownerName, "Owner name");
        this.vehicleType = Objects.requireNonNull(vehicleType, "Vehicle type is required");
    }

    public String getRegistrationNumber() {
        return registrationNumber;
    }

    public String getOwnerName() {
        return ownerName;
    }

    public VehicleType getVehicleType() {
        return vehicleType;
    }

    public void setOwnerName(String ownerName) {
        this.ownerName = requireText(ownerName, "Owner name");
    }

    /** Small guard used by the constructor and the setter so both enforce the same rule. */
    private static String requireText(String value, String fieldName) {
        if (value == null || value.isBlank()) {
            throw new IllegalArgumentException(fieldName + " cannot be empty");
        }
        return value.trim();
    }

    @Override
    public String toString() {
        return "Vehicle{registrationNumber='%s', ownerName='%s', vehicleType=%s}"
                .formatted(registrationNumber, ownerName, vehicleType);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) return true;
        if (!(other instanceof Vehicle that)) return false;
        return registrationNumber.equalsIgnoreCase(that.registrationNumber);
    }

    @Override
    public int hashCode() {
        return registrationNumber.toUpperCase().hashCode();
    }
}
