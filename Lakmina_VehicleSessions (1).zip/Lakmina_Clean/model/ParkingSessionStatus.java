package com.smartpark.model;

/** The lifecycle of a parking session: open (ACTIVE) or closed (COMPLETED). */
public enum ParkingSessionStatus {

    ACTIVE,
    COMPLETED;

    public boolean isActive() {
        return this == ACTIVE;
    }
}
