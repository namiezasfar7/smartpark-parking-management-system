package com.smartpark.repository;

import com.smartpark.model.Vehicle;
import java.util.List;

/**
 * Storage contract for vehicles. Same three methods the rest of the app
 * already depends on — existsByRegistrationNumber() is new but is a
 * default method, so it doesn't break whatever already implements this
 * interface.
 */
public interface VehicleRepository {

    void save(Vehicle vehicle);

    Vehicle findByRegistrationNumber(String registrationNumber);

    List<Vehicle> findAll();

    default boolean existsByRegistrationNumber(String registrationNumber) {
        return findByRegistrationNumber(registrationNumber) != null;
    }
}
