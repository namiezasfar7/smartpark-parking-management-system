package com.smartpark.repository;

import com.smartpark.model.ParkingSession;
import java.util.List;

/**
 * Storage contract for parking sessions. Same three methods as before —
 * existsBySessionId() is new but is a default method, so it doesn't break
 * whatever already implements this interface.
 */
public interface ParkingSessionRepository {

    void save(ParkingSession parkingSession);

    ParkingSession findBySessionId(String sessionId);

    List<ParkingSession> findAll();

    default boolean existsBySessionId(String sessionId) {
        return findBySessionId(sessionId) != null;
    }
}
